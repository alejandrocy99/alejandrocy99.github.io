/**
 * La función $(document).ready() de jQuery 
 * ejecuta este código cuando se carga totalmente
 * la página (index.html).
 */

$(document).ready(function() {
    draw();
    draw1();
    draw2();
    draw3();
    draw4();
    draw5();
    draw6();
    draw7();
    $.controlador.init("panel_inicio");
});